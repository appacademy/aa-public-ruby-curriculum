# README

This project demonstrates using Action Cable with Rails!