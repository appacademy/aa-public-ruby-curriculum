module ApplicationCable
  class Connection < ActionCable::Connection::Base
    # Your code here
  end
end