import React from 'react';

import GiphysIndexItem from './giphys_index_item';
