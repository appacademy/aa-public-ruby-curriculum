# A Simple Component Demo

To see it run:  

1.	[Download][zip] and open the directory in your terminal.
2.	Run `./server.sh` and navigate to localhost:8000.

[zip]: ../simple_component.zip?raw=true
