require 'json'

class Flash
end
