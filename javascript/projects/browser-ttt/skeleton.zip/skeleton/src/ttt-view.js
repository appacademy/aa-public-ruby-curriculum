class View {
  constructor(game, el) {}

  setupBoard() {}
  
  bindEvents() {}

  handleClick(e) {}

  makeMove(square) {}

}

module.exports = View;
