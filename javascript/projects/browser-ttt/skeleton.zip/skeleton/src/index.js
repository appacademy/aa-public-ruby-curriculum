const View = // require appropriate file
const Game = // require appropriate file

document.addEventListener("DOMContentLoaded", () => {
  // Your code here
});
