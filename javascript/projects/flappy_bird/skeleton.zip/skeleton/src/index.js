import FlappyBird from './game';

const canvas = document.getElementById('bird-game');
new FlappyBird(canvas);